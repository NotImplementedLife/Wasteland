#ifndef STATE_ADVENTURE_H
#define STATE_ADVENTURE_H

#include "shim/gb_shim.h"

void Start_Adventure();
void Update_Adventure();

#endif
