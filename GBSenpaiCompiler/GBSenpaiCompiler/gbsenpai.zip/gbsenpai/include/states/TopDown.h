#ifndef STATE_TOP_DOWN_H
#define STATE_TOP_DOWN_H

#include "shim/gb_shim.h"

void Start_TopDown();
void Update_TopDown();

#endif
