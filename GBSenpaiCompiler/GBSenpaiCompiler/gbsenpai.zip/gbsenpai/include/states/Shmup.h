#ifndef STATE_SHMUP_H
#define STATE_SHMUP_H

#include "shim/gb_shim.h"

void Start_Shmup();
void Update_Shmup();

#endif
